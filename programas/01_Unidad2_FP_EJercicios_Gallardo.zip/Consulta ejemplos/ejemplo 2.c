#include <stdio.h>
#include <math.h>

// Definición de la nueva función que combina fabs() y ceil()
double fabs_ceil(double num);

int main() {
    double num1 = -2.3;
    double num2 = 3.8;
    double num3 = -4.0;
    double num4 = 0.0;

    printf("fabs_ceil(%.1f) = %.1f\n", num1, fabs_ceil(num1));
    printf("fabs_ceil(%.1f) = %.1f\n", num2, fabs_ceil(num2));
    printf("fabs_ceil(%.1f) = %.1f\n", num3, fabs_ceil(num3));
    printf("fabs_ceil(%.1f) = %.1f\n", num4, fabs_ceil(num4));

    return 0;
}

double fabs_ceil(double num)
{
    // Primero obtenemos el valor absoluto de num
    double abs_value = fabs(num);
    // Luego redondeamos el valor absoluto hacia arriba
    return ceil(abs_value);
}
