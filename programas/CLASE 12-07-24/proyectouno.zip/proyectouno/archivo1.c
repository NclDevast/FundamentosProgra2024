//crear funciones
#include "stdio.h"

int suma(int a, int b)
{
    int s;
    return s=a+b;
}
int rest(int a, int b)
{
    int s;
    return s=a-b;
}
