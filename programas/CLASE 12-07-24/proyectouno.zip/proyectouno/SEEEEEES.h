#ifndef SEEEEEES_H_INCLUDED
#define SEEEEEES_H_INCLUDED

int repetidor(int num);

#endif // SEEEEEES_H_INCLUDED
