#ifndef AAAA_H_INCLUDED
#define AAAA_H_INCLUDED

//definir prototipos

int suma(int a, int b);
int rest(int a, int b);

#endif // AAAA_H_INCLUDED
