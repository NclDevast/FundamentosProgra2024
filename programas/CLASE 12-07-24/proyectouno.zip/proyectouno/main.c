#include <stdio.h>
#include <stdlib.h>
#include "AAAA.h"
#include "SEEEEEES.h"

int main()
{
     int a=4,b=5,sum,resta,num=0,resultado=0;
     sum=suma(a,b);
     resta=rest(a,b);
     printf("\n%d",sum);
     printf("\n%d",resta);
     printf("\nIngrese su numero");
     scanf("%d",&num);
     resultado=repetidor(num);

}
