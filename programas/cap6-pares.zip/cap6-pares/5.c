#include <stdio.h>
void valorAbsoluto(int *numero);
int main() 
{
    int numero;
    printf("Introduce un número: ");
    scanf("%d", &numero);
    valorAbsoluto(&numero);
    printf("El valor absoluto es: %d\n", numero);
}
void valorAbsoluto(int *numero) // funcion que calcula el valor absoluto de un numero
{
    if (*numero<0)  // solo es necesario editar el contenido del puntero si es negativo
    {
        *numero=-*numero;
    }
}