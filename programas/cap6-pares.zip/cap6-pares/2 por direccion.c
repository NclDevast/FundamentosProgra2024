#include "stdio.h"

void mayor(int *resultado, int a, int b);
void leer(int *a);

int main(void)
{
    int num1, num2, resultado;
    leer(&num1);
    leer(&num2);
    mayor(&resultado, num1, num2);
    printf("El mayor n�mero es: %d\n", resultado);
}

void leer(int *a)
{
    printf("Ingrese un n�mero: ");
    scanf("%d", a);
}

void mayor(int *resultado, int a, int b)
{
    if (a > b)
    {
        *resultado = a;
    }
    else
    {
        *resultado = b;
    }
}