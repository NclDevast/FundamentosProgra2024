#include <stdio.h>
void Salario(double *salarioTotal, int horasTrabajadas, double *salarioPorHora);
void horast(int *horas, double *salarioPorHora);

int main(void) 
{
    int horas;
    double salarioPorHora, salarioTotal;
    horast(&horas,&salarioPorHora);
    Salario(&salarioTotal,horas,&salarioPorHora);
    printf("El salario total es: %.2f\n",salarioTotal); 
}   

void horast(int *horas, double *salarioPorHora) //funcion que lee las horas trabajadas y el salario por hora
{
    printf("Ingrese el número de horas trabajadas: ");
    scanf("%d",horas); // se pasa el valor a la direccion de memoria del puntero horas
    printf("Ingrese el salario por hora: ");
    scanf("%lf",salarioPorHora); // se pasa el valor a la direccion de memoria del puntero salarioporhora
}

void Salario(double *salarioTotal, int horasTrabajadas, double *salarioPorHora) 
{
    int horasExtras;
    if (horasTrabajadas<=40) // se verifica si las horas son menores o iguales a cuarenta
    {
        *salarioTotal=horasTrabajadas*(*salarioPorHora); //si se cumple la condicion se asigna el salario normal al puntero salario total
    } 
    else // de lo contrario se realiza el calculo de las horas extras y el pago con un multiplicador de 1.5 a las horas extras.
    {
        horasExtras=horasTrabajadas-40;  
        *salarioTotal=(40*(*salarioPorHora))+(horasExtras*(*salarioPorHora*1.5));
    }
}
