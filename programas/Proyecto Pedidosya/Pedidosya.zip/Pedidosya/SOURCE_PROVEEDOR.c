#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "FUNCIONES1.h"

void seleccionproveedorrand (int *perfilproveedor, int eleccionrestaurante)
{
    int proveedor;
    srand(time(NULL));
    proveedor=rand()%(2-0+1)+0;
    *(perfilproveedor+eleccionrestaurante*3+proveedor)=*(perfilproveedor+eleccionrestaurante*3+0)+1;
    return;
}
