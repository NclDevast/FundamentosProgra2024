#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void menuusuario(const char **perfilusuario,const char **perfilproveedor,const char **restaurantes,const char **menumc,const char **menubk,const char **menumotes,const float *preciosmc,const float *preciosbk,const float *preciosmotes,const char **nombreusuario);
void menuproveedor(const char **perfilusuario,const char **perfilproveedor,const char **restaurantes,const char **menumc,const char **menubk,const char **menumotes,const float *preciosmc,const float *preciosbk,const float *preciosmotes,const char **nombreusuario);
void revisarpedidoproveedor(const char **restaurantes,const char ** menumc,const char **menubk,const char**menumotes, int *pproveedor,const float *preciosmc,const float *preciosbk,const float *preciosmotes,const char **nombreusuario);
int validacion(const char **perfilusuario,const char **perfilproveedor, int identificador, int *pusuario, int *pproveedor, const char **nombreusuario);
void hacerpedido(const char **restaurantes,const char ** menumc,const char **menubk,const char**menumotes, int *pusuario,const float *preciosmc,const float *preciosbk,const float*preciosmotes,float *pcarrito1,float *pcarrito2, float *pcarrito3);
void revisarpedido(const char **restaurantes,const char ** menumc,const char **menubk,const char**menumotes, int *pusuario);
void imprimirordenes(const char ** menumc,const char **menubk,const char**menumotes, int *pusuario, int j, int i);
void imprimirpendientes(const char **menumc,const char **menubk,const char**menumotes,int *pproveedor,const float *preciosmc,const float *preciosbk,const float *preciosmotes);
int seleccionproveedorrand();
int seleccionitem();
void imprimirMatriz(int pedidos[3][3]);
void limpiarpantalla();

#endif // FUNCIONES_H_INCLUDED
