#include "stdio.h"
#include "stdlib.h"
#include "FUNCIONES.h"
#include "string.h"

void menuusuario(const char **perfilusuario,const char **perfilproveedor, const char **restaurantes,const char **menumc, const char **menubk,const char **menumotes,const float *preciosmc,const float *preciosbk,const float*preciosmotes,const char **nombreusuario)
{
    int opcmenu, identificador=0,usuario,confirmacion=0,menu=0,proveedor;
    int *pusuario=&usuario,*pproveedor=&proveedor;
    float carrito1=0,carrito2=0,carrito3=0;
    float *pcarrito1=&carrito1,*pcarrito2=&carrito2,*pcarrito3=&carrito3;

    confirmacion=validacion(perfilusuario,perfilproveedor,identificador,pusuario,pproveedor,nombreusuario);

    if(confirmacion!=0)
    {
        limpiarpantalla();
        printf("\nUsuario o contrasena incorrecta");
        printf("\n");
        system("pause");
        system("cls");
        return;
    }
    else
    while (menu==0)
    {
        printf("\nSeleccione su opcion:\n1)Hacer pedido\n2)Revisar pedidos\n3)Salir\n");
        scanf("%d",&opcmenu);
        switch(opcmenu)
        {
        case 1:
            {
                limpiarpantalla();
                hacerpedido(restaurantes,menumc,menubk,menumotes,pusuario,preciosmc,preciosbk,preciosmotes,pcarrito1,pcarrito2,pcarrito3);
                break;
            }
        case 2:
            {
                limpiarpantalla();
                revisarpedido(restaurantes,menumc,menubk,menumotes,pusuario);
                break;
            }
        default:
            {
                limpiarpantalla();
                menu++;
                break;
            }
        }
    }

}

void hacerpedido(const char **restaurantes ,const char **menumc,const char **menubk,const char**menumotes,int *pusuario,const float *preciosmc,const float *preciosbk,const float*preciosmotes,float *pcarrito1,float *pcarrito2, float *pcarrito3)
{
    extern int pedidosmc[3][3]; //se aumenta el alcance de las variables para que funcionen como globales
    extern int pedidosbk[3][3];
    extern int pedidosmotes[3][3];

    int proveedor,itemordenado;

    proveedor=seleccionproveedorrand();

    if (proveedor<0||proveedor>2)
        return;
    printf("\nBienvenido a %s!\nMenu:",*(restaurantes+proveedor));
    switch(proveedor)
    {
    case 0: //McDonalds
        {
        for (int i=1;i<=3;i++)
            printf("\n%d)%s $%.2f.\n",i,*(menumc+i-1),*(preciosmc+i-1));
        itemordenado=seleccionitem();
        (pedidosmc[*pusuario][itemordenado-1])++;
        system("cls");
        printf("\nUsted ha ordenado:%s por $%.2f!\n",*(menumc+itemordenado-1),*(preciosmc+itemordenado-1));
        limpiarpantalla();
        break;
        }
    case 1:
        {
        for (int i=1;i<=3;i++)
            printf("\n%d)%s $%.2f\n",i,*(menubk+i-1),*(preciosbk+i-1));
        itemordenado=seleccionitem();
        (pedidosbk[*pusuario][itemordenado-1])++;
        system("cls");
        printf("\nUsted ha ordenado:%s por $%.2f!\n",*(menubk+itemordenado-1),*(preciosbk+itemordenado-1));
        limpiarpantalla();
        break;
        }
    case 2:
        {
        for (int i=1;i<=3;i++)
            printf("\n%d)%s. $%.2f\n",i,*(menumotes+i-1),*(preciosmotes+i-1));
        itemordenado=seleccionitem();
        (pedidosmotes[*pusuario][itemordenado-1])++;
        system("cls");
        printf("\nUsted ha ordenado:%s por $%.2f!\n",*(menumotes+itemordenado-1),*(preciosmotes+itemordenado-1));
        limpiarpantalla();
        break;
        }
    }
}

int seleccionitem()
{
    int seleccion;
    scanf("%d",&seleccion);
    if (seleccion<=0||seleccion>3)
    {
        printf("\nOpcion invalida!");
        return -1;
    }
    else return seleccion;
}

void revisarpedido(const char **restaurantes,const char ** menumc,const char **menubk,const char**menumotes, int *pusuario)
{
    extern int pedidosmc[3][3];
    extern int pedidosbk[3][3];
    extern int pedidosmotes[3][3];
    int j;
    for(int i=0;i<3;i++)
    {
        printf("\n%s: ",*(restaurantes+i));
        for (j=1;j<=3;j++)
        {
            imprimirordenes(menumc,menubk,menumotes,pusuario,j,i);
        }
        printf("\n");
        system("pause");
        system("cls");
    }
    return;
}
void imprimirordenes(const char ** menumc,const char **menubk,const char**menumotes, int *pusuario, int j, int i)
{
    int z;
    extern int pedidosmc[3][3];
    extern int pedidosbk[3][3];
    extern int pedidosmotes[3][3];
    if (j<1||j>3)
        return;
    switch(j)
    {
    case 1:
        {
            for (z=0;z<3;z++)
            {
                if(i==0)
                printf("\n%s: %i",*(menumc+z),pedidosmc[*pusuario][z]);
                else break;
            }
            break;
        }
    case 2:
        {
            for (int z=0;z<3;z++)
            {
                if(i==1)
                printf("\n%s: %i",*(menubk+z),pedidosbk[*pusuario][z]);
                else break;
            }
            break;
        }
    case 3:
        {
            for (z=0;z<3;z++)
            {
                if(i==2)
                printf("\n%s: %i",*(menumotes+z),pedidosmotes[*pusuario][z]);
                else break;
            }
            break;
        }
    default:
        break;
    }
    return;
}

