#include <stdio.h>
#include <stdlib.h>
#include "FUNCIONES.h"
    int pedidosmc[3][3]={0};
    int pedidosbk[3][3]={0};
    int pedidosmotes[3][3]={0};

int main(void)
{
    const char *nombreusuario[3]={"Julia","Jorge","Pedro"};
    const char *perfilusuario[3]={"EstrellaBonita2","contrasena1234","yy5bvUnFYc"};
    const char *perfilproveedor[3]={"JuanMcdonanlds1234","asdfgh666","un4PulG4aVentura2003"};
    const char *restaurantes[3]={"McDonalds","Burger King","Los motes de la Magdalena"};
    const char *menumc[3]={"Big Mac","McMelt","McNuggets"};
    const char *menubk[3]={"Whopper","Whopper Junior","Bk Nuggets"};
    const char *menumotes[3]={"Mote con Chicharron","Motepillo","Llapingacho"};
    const float preciosmc[3]={6.5,8.99,4.99};
    const float preciosbk[3]={9.99,6.99,5.99};
    const float preciosmotes[3]={5.25,3,5.99};

    int opcusuario=0;
    while(1)
    {
        printf("\nBienvenido! Escoja como desea iniciar\n1)Usuario\n2)Proveedor\n3)Salir\n");
        scanf("%d",&opcusuario);
        system("cls");
        switch(opcusuario)
        {
        case 1:
            {
                limpiarpantalla();
                menuusuario(perfilusuario,perfilproveedor,restaurantes,menumc,menubk,menumotes,preciosmc,preciosbk,preciosmotes,nombreusuario);
                break;
            }
        case 2:
            {
                limpiarpantalla();
                menuproveedor(perfilusuario,perfilproveedor,restaurantes,menumc,menubk,menumotes,preciosmc,preciosbk,preciosmotes,nombreusuario);
                break;
            }
        case 3:
            {
                exit (0);
            }
        default:
            {
                printf("\nOpcion Invalida!");
            }
        }
    //imprimirMatriz(pedidosmc); //debug
    }
}
