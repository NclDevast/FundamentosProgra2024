#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "FUNCIONES.h"

int seleccionproveedorrand ()
{
    int num;
    srand(time(NULL));
    num=rand()%(2-0+1)+0;
    return num;
}

void menuproveedor(const char **perfilusuario,const char **perfilproveedor, const char **restaurantes,const char **menumc, const char **menubk,const char **menumotes, const float *preciosmc,const float *preciosbk,const float *preciosmotes,const char **nombreusuario)
{
    int opcmenu, identificador=1,proveedor,usuario,confirmacion,menu=0;
    int *pproveedor=&proveedor,*pusuario=&usuario;
    confirmacion=validacion(perfilusuario,perfilproveedor,identificador,pusuario,pproveedor,nombreusuario);
    if(confirmacion<0)
    {
        limpiarpantalla();
        printf("\nUsuario o contrasena incorrecta");
        printf("\n");
        system("pause");
        system("cls");
        return;
    }
    else
    while (menu==0)
    {
        printf("\nSeleccione su opcion:\n1)Revisar Pedidos\n2)Salir\n");
        scanf("%d",&opcmenu);
        switch(opcmenu)
        {
        case 1:
            {
                limpiarpantalla();
                revisarpedidoproveedor(restaurantes,menumc,menubk,menumotes,pproveedor,preciosmc,preciosbk,preciosmotes,nombreusuario);
                break;
            }
        case 2:
            {
                //realizarpedidos(restaurantes,menumc,menubk,menumotes,pproveedor);
                menu++;
                break;
            }
        case 3:
            {
                menu++;
                break;
            }
        default:
            {
                printf("\nOpcion invalida!");
                break;
            }
        }
    }
}

void revisarpedidoproveedor(const char **restaurantes,const char ** menumc,const char **menubk,const char**menumotes, int *pproveedor,const float *preciosmc,const float *preciosbk,const float *preciosmotes,const char **nombreusuario)
{
    extern int pedidosmc[3][3];
    extern int pedidosbk[3][3];
    extern int pedidosmotes[3][3];

    int z=0,i=0,totalproductos=0;

    limpiarpantalla();

    //printf("\%d",*pproveedor);

    switch(*pproveedor)
    {
    case 1:
        {
            for(z=0;z<3;z++)
            {
                printf("\nUsuario %s",*(nombreusuario+z));
                for(i=0;i<3;i++)
                printf("\n %d %s",pedidosmc[z][i],*(menumc+i));
            }
            printf("\n");
            system("pause");
            limpiarpantalla();
            break;
        }
    case 2:
        {
            for(z=0;z<3;z++)
            {
                printf("\nUsuario %s",*(nombreusuario+z));
                for(i=0;i<3;i++)
                printf("\n %d %s",pedidosbk[z][i],*(menubk+i));
            }
            printf("\n");
            system("pause");
            limpiarpantalla();
            break;
        }
    case 3:
        {
            for(z=0;z<3;z++)
            {
                printf("\nUsuario %s",*(nombreusuario+z));
                for(i=0;i<3;i++)
                printf("\n %d %s",pedidosmotes[z][i],*(menumotes+i));
            }
            printf("\n");
            system("pause");
            limpiarpantalla();
            break;
        }
    default:
        break;
    }
}
