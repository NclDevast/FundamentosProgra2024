#include "stdio.h"
#include "stdlib.h"
#include "FUNCIONES.h"
#include "string.h"
#include "windows.h"
#include "unistd.h"

int validacion(const char **perfilusuario,const char **perfilproveedor, int identificador, int *pusuario, int *pproveedor, const char **nombreusuario)
{
    int confirmacion=0,opcusuario=0, i;
    char contrasena[50];
    switch(identificador)
    {
    case 0:
        {
            printf("\nEscoja su usuario:");
            for (i=1;i<=3;i++)
            {
                printf("\n%d)Usuario %s.\n",i,*(nombreusuario+i-1));
            }
            scanf("%d",&opcusuario);
            system("cls");
            printf("\nIngrese su contrasena: ");
            scanf("%s",contrasena);
            system("cls");
            if(strcmp(contrasena,perfilusuario[opcusuario-1])!=0)
                {
                    return -1;
                }
            else
            {
             limpiarpantalla();
             printf("\nInicio exitoso! Bienvenida %s!",*(nombreusuario+(opcusuario-1)));
             *pusuario=opcusuario-1;
             return 0;
            }
        }
    case 1:
        {
            char *nombreproveedor[3]={"McDonnalds","Burger King","Motes de Magdalena"};
            printf("\nEscoja su usuario:");
            for (i=1;i<=3;i++)
            {
                printf("\n%d)Usuario %s.\n",i,nombreproveedor[i-1]);
            }
            scanf("%d",&opcusuario);
            system("cls");
            printf("\nIngrese su contrasena: ");
            scanf("%s",contrasena);
            system("cls");
            if(strcmp(contrasena,perfilproveedor[opcusuario-1])!=0)
                return -1;
            else
            {
             limpiarpantalla();
             printf("\nInicio exitoso! Bienvenida %s!",nombreproveedor[opcusuario-1]);
             *pproveedor=opcusuario;
             return 0;
            }

        }
    default:
        {
            return -1;
        }
    }
}

void imprimirMatriz(int pedidos[3][3]) // debug
{
    printf("\n");
    for (int i=0;i<3;i++)
    {
        for (int j=0;j<3;j++)
        {
            printf("%d ",pedidos[i][j]);
        }
        printf("\n");
    }
}

void limpiarpantalla()
{
    sleep(1.5);
    system("cls");
    printf("\nCargando...");
    sleep(1.2);
    printf("Cargando...");
    sleep(1.2);
    system("cls");
}
